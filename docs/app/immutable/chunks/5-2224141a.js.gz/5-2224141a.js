import{_ as r}from"./_page-207fd8ec.js";import{default as t}from"../components/pages/menu/_page.svelte-4ae32be0.js";export{t as component,r as universal};
