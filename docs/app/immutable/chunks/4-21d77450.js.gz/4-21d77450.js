import{_ as r}from"./_page-75379c46.js";import{default as t}from"../components/pages/logo/_page.svelte-48baeb4f.js";export{t as component,r as universal};
