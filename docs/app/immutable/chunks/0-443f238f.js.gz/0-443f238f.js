import{default as t}from"../components/pages/_layout.svelte-539ada3b.js";export{t as component};
