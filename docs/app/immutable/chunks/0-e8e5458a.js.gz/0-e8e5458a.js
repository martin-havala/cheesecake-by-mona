import{default as t}from"../components/pages/_layout.svelte-1a99c817.js";export{t as component};
