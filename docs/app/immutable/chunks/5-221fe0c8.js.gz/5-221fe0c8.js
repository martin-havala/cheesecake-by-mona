import{_ as r}from"./_page-bffe94d6.js";import{default as t}from"../components/pages/menu/_page.svelte-0cea5be1.js";export{t as component,r as universal};
