import{b as t}from"./paths-b4419565.js";function n(e){return`${t}/bake?data=${encodeURIComponent(JSON.stringify(e))}`}export{n as g};
