import{default as t}from"../components/error.svelte-71c3815c.js";export{t as component};
