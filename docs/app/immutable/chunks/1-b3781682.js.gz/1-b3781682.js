import{default as t}from"../components/error.svelte-3c4d006f.js";export{t as component};
