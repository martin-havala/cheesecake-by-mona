import{default as t}from"../components/error.svelte-b7c847fd.js";export{t as component};
