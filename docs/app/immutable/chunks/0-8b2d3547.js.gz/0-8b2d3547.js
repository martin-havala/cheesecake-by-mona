import{default as t}from"../components/pages/_layout.svelte-705f38ae.js";export{t as component};
