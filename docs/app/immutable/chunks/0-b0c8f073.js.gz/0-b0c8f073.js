import{default as t}from"../components/pages/_layout.svelte-db35c3df.js";export{t as component};
