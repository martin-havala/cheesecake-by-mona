import{default as t}from"../components/pages/_layout.svelte-6f1b26be.js";export{t as component};
