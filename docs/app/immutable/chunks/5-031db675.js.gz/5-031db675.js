import{_ as r}from"./_page-fcb137e8.js";import{default as t}from"../components/pages/menu/_page.svelte-1a5843fe.js";export{t as component,r as universal};
