import{default as t}from"../components/pages/_layout.svelte-086bd994.js";export{t as component};
