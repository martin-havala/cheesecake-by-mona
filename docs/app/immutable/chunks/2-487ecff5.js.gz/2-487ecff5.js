import{_ as r}from"./_page-bffe94d6.js";import{default as t}from"../components/pages/_page.svelte-1d40afa8.js";export{t as component,r as universal};
