import{_ as r}from"./_page-bffe94d6.js";import{default as t}from"../components/pages/_page.svelte-ada325f7.js";export{t as component,r as universal};
