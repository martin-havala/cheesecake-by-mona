import{_ as r}from"./_page-3236f0fd.js";import{default as t}from"../components/pages/logo/_page.svelte-1f25a60c.js";export{t as component,r as universal};
