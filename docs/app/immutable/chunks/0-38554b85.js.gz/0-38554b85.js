import{default as t}from"../components/pages/_layout.svelte-9397d6d4.js";export{t as component};
