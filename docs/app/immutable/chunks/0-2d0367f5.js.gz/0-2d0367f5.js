import{default as t}from"../components/pages/_layout.svelte-8d298cff.js";export{t as component};
