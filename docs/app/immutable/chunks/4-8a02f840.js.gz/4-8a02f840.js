import{_ as r}from"./_page-75379c46.js";import{default as t}from"../components/pages/logo/_page.svelte-8c9bd09f.js";export{t as component,r as universal};
