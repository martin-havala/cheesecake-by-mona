import{_ as r}from"./_page-91fa1d72.js";import{default as t}from"../components/pages/bake/_page.svelte-4c5966cb.js";export{t as component,r as universal};
