import{default as t}from"../components/pages/_layout.svelte-565a7a09.js";export{t as component};
