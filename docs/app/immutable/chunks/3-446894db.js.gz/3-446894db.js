import{_ as r}from"./_page-fcb137e8.js";import{default as t}from"../components/pages/bake/_page.svelte-b3623f0a.js";export{t as component,r as universal};
