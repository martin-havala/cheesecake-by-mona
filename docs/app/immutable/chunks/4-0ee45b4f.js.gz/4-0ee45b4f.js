import{_ as r}from"./_page-75379c46.js";import{default as t}from"../components/pages/byMona/_page.svelte-c05492ed.js";export{t as component,r as universal};
