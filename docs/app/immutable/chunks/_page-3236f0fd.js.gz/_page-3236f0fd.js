const e=!0,r=!1,s=!0,t=Object.freeze(Object.defineProperty({__proto__:null,csr:!0,ssr:!1,prerender:!0},Symbol.toStringTag,{value:"Module"}));export{t as _,e as c,s as p,r as s};
