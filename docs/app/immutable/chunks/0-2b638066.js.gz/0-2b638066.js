import{default as t}from"../components/pages/_layout.svelte-89139818.js";export{t as component};
