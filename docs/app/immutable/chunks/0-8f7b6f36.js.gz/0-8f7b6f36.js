import{default as t}from"../components/pages/_layout.svelte-dcc83cf7.js";export{t as component};
