import{_ as r}from"./_page-fcb137e8.js";import{default as t}from"../components/pages/logo/_page.svelte-37d6d3e3.js";export{t as component,r as universal};
