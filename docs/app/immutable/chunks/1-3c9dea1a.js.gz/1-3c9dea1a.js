import{default as t}from"../components/error.svelte-939ed77b.js";export{t as component};
