import{default as t}from"../components/error.svelte-160a8d97.js";export{t as component};
