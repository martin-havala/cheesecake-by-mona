import{_ as r}from"./_page-919831ca.js";import{default as t}from"../components/pages/menu/_page.svelte-20a779f8.js";export{t as component,r as universal};
