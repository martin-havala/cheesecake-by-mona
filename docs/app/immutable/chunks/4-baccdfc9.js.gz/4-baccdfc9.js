import{_ as r}from"./_page-75379c46.js";import{default as t}from"../components/pages/logo/_page.svelte-aa0d0e84.js";export{t as component,r as universal};
