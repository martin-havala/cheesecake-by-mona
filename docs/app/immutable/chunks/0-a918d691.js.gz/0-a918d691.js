import{default as t}from"../components/pages/_layout.svelte-ce799555.js";export{t as component};
