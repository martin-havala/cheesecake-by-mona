import{_ as r}from"./_page-75379c46.js";import{default as t}from"../components/pages/bake/_page.svelte-cf174f0d.js";export{t as component,r as universal};
