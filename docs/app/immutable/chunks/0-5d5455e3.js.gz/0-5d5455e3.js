import{default as t}from"../components/pages/_layout.svelte-327c67a4.js";export{t as component};
