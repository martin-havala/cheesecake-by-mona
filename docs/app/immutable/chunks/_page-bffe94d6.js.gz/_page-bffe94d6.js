const e=!0,r=!0,t=Object.freeze(Object.defineProperty({__proto__:null,csr:!0,prerender:!0},Symbol.toStringTag,{value:"Module"}));export{t as _,e as c,r as p};
