import{_ as r}from"./_page-207fd8ec.js";import{default as t}from"../components/pages/menu/_page.svelte-c619b882.js";export{t as component,r as universal};
