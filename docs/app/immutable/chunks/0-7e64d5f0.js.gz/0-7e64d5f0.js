import{default as t}from"../components/pages/_layout.svelte-0b82b24d.js";export{t as component};
