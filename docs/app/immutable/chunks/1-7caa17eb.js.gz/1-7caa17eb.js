import{default as t}from"../components/error.svelte-9fcb7b4b.js";export{t as component};
