import{default as t}from"../components/error.svelte-1e00bba8.js";export{t as component};
