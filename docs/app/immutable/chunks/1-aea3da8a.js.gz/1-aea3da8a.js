import{default as t}from"../components/error.svelte-7390710c.js";export{t as component};
