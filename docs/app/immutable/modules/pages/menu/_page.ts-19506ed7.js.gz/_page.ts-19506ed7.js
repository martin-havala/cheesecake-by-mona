import{c as p,p as s}from"../../../chunks/_page-919831ca.js";export{p as csr,s as prerender};
